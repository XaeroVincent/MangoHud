#!/bin/sh
# MangoHUD for Linux games (FreeBSD Linuxulator)
#
# Usage:
#   mangohud-linux.sh PROGRAM [ARGUMENTS...]
#   mangohud-linux.sh --dir FOLDER PROGRAM [ARGUMENTS...]
#
# Examples:
#   ./mangohud-linux.sh ./MyGame
#   ./mangohud-linux.sh --dir "/path/with spaces/MyGame" ./binary
#
# Installs nothing on the system and does not modify the game.

base=$(dirname "$(realpath "$0")")
libs="$base/lib64"

usage() {
    echo "Usage:"
    echo "  $(basename "$0") PROGRAM [ARGUMENTS...]"
    echo "  $(basename "$0") --dir FOLDER PROGRAM [ARGUMENTS...]"
    echo
    echo "Examples:"
    echo "  $(basename "$0") ./MyGame"
    echo "  $(basename "$0") --dir \"/path/to/game\" ./binary"
    echo
    echo "Useful variables:"
    echo "  MANGOHUD_CONFIG=fps=1,position=top-left"
    echo "  MANGOHUD_LOG_LEVEL=debug"
}

case "$1" in
    -h|--help)
        usage
        exit 0
        ;;
esac

if [ "$1" = "--dir" ]; then
    if [ "$#" -lt 3 ]; then
        usage
        exit 1
    fi
    folder=$2
    shift 2
    cd "$folder" || exit 1
fi

if [ "$#" -lt 1 ]; then
    usage
    exit 1
fi

# MangoHUD built for Linux x86_64/glibc 2.34 (EPEL 9).
# Names without "/" are used so spaces in the folder path do not break
# LD_PRELOAD; the Linux loader finds them through LD_LIBRARY_PATH.
export LD_LIBRARY_PATH="$libs/mangohud:$libs${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export LD_PRELOAD="libMangoHud_dlsym.so:libMangoHud_opengl_fixed.so${LD_PRELOAD:+:$LD_PRELOAD}"

export MANGOHUD=1

# Linuxulator has no /sys/class/hwmon; without this MangoHUD fills the
# terminal with errors every half second. Set it to debug when investigating.
export MANGOHUD_LOG_LEVEL="${MANGOHUD_LOG_LEVEL:-off}"

# dlsym is required for games that resolve OpenGL dynamically
# (SDL2, GLFW, etc.). The "_fixed" binary carries the
# /proc/self/map_files patch that Linuxulator does not implement.
exec "$@"
