#!/bin/sh
# Quick test: opens Linux glxgears with MangoHUD.
# You should see the overlay in the top-left corner.
#
# Close the window or press Ctrl+C to finish.

base=$(dirname "$(realpath "$0")")
gears="/compat/linux/usr/bin/glxgears"

if [ ! -x "$gears" ]; then
    echo "Cannot find $gears"
    echo "Install the linux-rl9-glx-utils package (or equivalent)."
    exit 1
fi

# Eye-catching settings just for this test.
# If MANGOHUD_CONFIG is already set, your value is kept.
: "${MANGOHUD_CONFIG:=position=top-left,background_alpha=1,fps=1,font_size=20}"
export MANGOHUD_CONFIG

exec "$base/mangohud-linux.sh" "$gears"
