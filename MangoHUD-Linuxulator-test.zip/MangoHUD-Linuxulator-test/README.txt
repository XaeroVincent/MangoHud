Requirements
------------
- FreeBSD with Linuxulator enabled (linux-rl9 package or similar).
- A Linux x86_64 game or program that you run with Linuxulator.
- A graphics card with working OpenGL under Linuxulator.
- For the automatic test: /compat/linux/usr/bin/glxgears
  (linux-rl9-glx-utils package or equivalent).


Basic usage
----------

    ./mangohud-linux.sh ./MyGame

Usage with a working folder (useful if the game looks for its files
next to the executable):

    ./mangohud-linux.sh --dir "/path/to/folder" ./binary

  --dir FOLDER   enters FOLDER before launching the program.
  Everything after that is passed to the program as-is, including
  arguments with spaces if you quote them.

Examples:

    ./mangohud-linux.sh --dir "$HOME/games/MyGame" ./MyGame

    ./mangohud-linux.sh --dir "$HOME/games/MyGame" ./run.sh

    ./mangohud-linux.sh /path/to/game/64/MyGame --fullscreen


Testing it
----------
Run the included test:

    ./test.sh

A window with gears should open, with the MangoHUD overlay in the
top-left corner (FPS, CPU, GPU...). Close the window or press Ctrl+C
to finish.

If you see the overlay, MangoHUD is working.

Origin and patch
----------------
The libraries come from EPEL 9 RPM packages for Linux x86_64:
    mangohud-0.7.1-3.el9
    spdlog-1.10.0-2.el9
    fmt-8.1.1-5.el9

FreeBSD's original MangoHUD cannot be injected into Linux processes,
so the Linux version is used.

Known issue: MangoHUD tries to read /proc/self/map_files, which
FreeBSD's Linuxulator does not implement, and exits with a filesystem
error. The *_fixed.so library has that string changed to /proc/self/fd
(padded with zeros so the size does not change), which avoids the
crash. It is the only change from the original MangoHUD.
